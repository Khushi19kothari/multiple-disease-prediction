# multiple-disease-prediction

URL: https://multiple-disease-prediction-py.streamlit.app/
